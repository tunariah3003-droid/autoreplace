package com.example.autorodswitch;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = "autorodswitch", value = Dist.CLIENT)
public class Keybinds {
    private static KeyMapping toggleKey;

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        toggleKey = new KeyMapping(
                "key.autorodswitch.toggle",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_R, // mặc định phím R
                "key.categories.misc"
        );
        event.register(toggleKey);
    }

    @SubscribeEvent
    public static void onKey(InputEvent.Key event) {
        if (toggleKey != null && toggleKey.consumeClick()) {
            AutoRodSwitch.toggle();
        }
    }
}
