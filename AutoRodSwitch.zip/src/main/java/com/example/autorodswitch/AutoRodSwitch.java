package com.example.autorodswitch;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientTickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.FishingRodItem;

@Mod("autorodswitch")
public class AutoRodSwitch {

    private final Minecraft mc = Minecraft.getInstance();
    private static boolean enabled = true; // bật/tắt mod

    public AutoRodSwitch() {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(this);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new Keybinds());
    }

    public static void toggle() {
        enabled = !enabled;
        String msg = enabled ? "§a[AutoRodSwitch] Đã bật" : "§c[AutoRodSwitch] Đã tắt";
        Minecraft.getInstance().gui.getChat().addMessage(net.minecraft.network.chat.Component.literal(msg));
    }

    @SubscribeEvent
    public void onClientTick(ClientTickEvent event) {
        if (event.phase != ClientTickEvent.Phase.END) return;
        if (!enabled) return;

        LocalPlayer player = mc.player;
        if (player == null) return;

        ItemStack inHand = player.getMainHandItem();

        // Chỉ chạy khi đang cầm cần câu
        if (!(inHand.getItem() instanceof FishingRodItem)) return;

        // Nếu tay trống hoặc cần không còn
        if (inHand.isEmpty() || !(inHand.getItem() instanceof FishingRodItem)) {
            for (int i = 0; i < 9; i++) {
                ItemStack stack = player.getInventory().getItem(i);
                if (!stack.isEmpty() && stack.getItem() instanceof FishingRodItem) {
                    player.getInventory().selected = i;
                    break;
                }
            }
        }
    }
}
